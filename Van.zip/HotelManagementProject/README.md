# Hotel Management 
### Đồ án Hệ thống quản lý Khách sạn IVIVU online

### Chức năng 

1. Đăng kí, đăng nhập - đăng xuất
2. Tìm kiếm và đặt phòng khách sạn
3. Quản lý và tìm kiếm hóa đơn
4. Quản lý báo cáo, thống kê
