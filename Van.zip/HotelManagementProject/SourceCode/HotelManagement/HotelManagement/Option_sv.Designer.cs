﻿namespace HotelManagement
{
    partial class Option_sv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TimKiemHoaDon = new System.Windows.Forms.Button();
            this.QuanLyHoaDon = new System.Windows.Forms.Button();
            this.QuanLyThongKe = new System.Windows.Forms.Button();
            this.QuanLyBaoCao = new System.Windows.Forms.Button();
            this.datkhachsanserver = new System.Windows.Forms.GroupBox();
            this.datkhachsanserver.SuspendLayout();
            this.SuspendLayout();
            // 
            // TimKiemHoaDon
            // 
            this.TimKiemHoaDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(3)))), ((int)(((byte)(149)))));
            this.TimKiemHoaDon.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimKiemHoaDon.ForeColor = System.Drawing.Color.White;
            this.TimKiemHoaDon.Location = new System.Drawing.Point(75, 96);
            this.TimKiemHoaDon.Name = "TimKiemHoaDon";
            this.TimKiemHoaDon.Size = new System.Drawing.Size(500, 35);
            this.TimKiemHoaDon.TabIndex = 11;
            this.TimKiemHoaDon.Text = "Tìm kiếm thông tin hóa đơn";
            this.TimKiemHoaDon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TimKiemHoaDon.UseVisualStyleBackColor = false;
            // 
            // QuanLyHoaDon
            // 
            this.QuanLyHoaDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(3)))), ((int)(((byte)(149)))));
            this.QuanLyHoaDon.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuanLyHoaDon.ForeColor = System.Drawing.Color.White;
            this.QuanLyHoaDon.Location = new System.Drawing.Point(75, 45);
            this.QuanLyHoaDon.Name = "QuanLyHoaDon";
            this.QuanLyHoaDon.Size = new System.Drawing.Size(500, 35);
            this.QuanLyHoaDon.TabIndex = 10;
            this.QuanLyHoaDon.Text = "Thêm thông tin hóa đơn";
            this.QuanLyHoaDon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QuanLyHoaDon.UseVisualStyleBackColor = false;
            // 
            // QuanLyThongKe
            // 
            this.QuanLyThongKe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(3)))), ((int)(((byte)(149)))));
            this.QuanLyThongKe.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuanLyThongKe.ForeColor = System.Drawing.Color.White;
            this.QuanLyThongKe.Location = new System.Drawing.Point(75, 199);
            this.QuanLyThongKe.Name = "QuanLyThongKe";
            this.QuanLyThongKe.Size = new System.Drawing.Size(500, 35);
            this.QuanLyThongKe.TabIndex = 14;
            this.QuanLyThongKe.Text = "Quản lý thống kê";
            this.QuanLyThongKe.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QuanLyThongKe.UseVisualStyleBackColor = false;
            // 
            // QuanLyBaoCao
            // 
            this.QuanLyBaoCao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(3)))), ((int)(((byte)(149)))));
            this.QuanLyBaoCao.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuanLyBaoCao.ForeColor = System.Drawing.Color.White;
            this.QuanLyBaoCao.Location = new System.Drawing.Point(75, 148);
            this.QuanLyBaoCao.Name = "QuanLyBaoCao";
            this.QuanLyBaoCao.Size = new System.Drawing.Size(500, 35);
            this.QuanLyBaoCao.TabIndex = 13;
            this.QuanLyBaoCao.Text = "Quản lý báo cáo";
            this.QuanLyBaoCao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.QuanLyBaoCao.UseVisualStyleBackColor = false;
            // 
            // datkhachsanserver
            // 
            this.datkhachsanserver.Controls.Add(this.QuanLyHoaDon);
            this.datkhachsanserver.Controls.Add(this.QuanLyThongKe);
            this.datkhachsanserver.Controls.Add(this.TimKiemHoaDon);
            this.datkhachsanserver.Controls.Add(this.QuanLyBaoCao);
            this.datkhachsanserver.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datkhachsanserver.Location = new System.Drawing.Point(265, 130);
            this.datkhachsanserver.Name = "datkhachsanserver";
            this.datkhachsanserver.Size = new System.Drawing.Size(795, 269);
            this.datkhachsanserver.TabIndex = 15;
            this.datkhachsanserver.TabStop = false;
            this.datkhachsanserver.Text = "HỆ THỐNG QUẢN LÝ ĐẶT KHÁCH SẠN IVIVU";
            // 
            // Option_sv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(124)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(1317, 739);
            this.Controls.Add(this.datkhachsanserver);
            this.Name = "Option_sv";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Option_sv";
            this.datkhachsanserver.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button TimKiemHoaDon;
        private System.Windows.Forms.Button QuanLyHoaDon;
        private System.Windows.Forms.Button QuanLyThongKe;
        private System.Windows.Forms.Button QuanLyBaoCao;
        private System.Windows.Forms.GroupBox datkhachsanserver;

    }
}