﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagement
{
    public partial class Option_cl : Form
    {
        public Option_cl()
        {
            InitializeComponent();
        }

        private void Option_cl_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TimKiemKhachSan_Click(object sender, EventArgs e)
        {

        }

        private void DatPhongKhachSan_Click(object sender, EventArgs e)
        {

        }

        private void DangXuat_Option_Click(object sender, EventArgs e)
        {

        }

        private void usernamelink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
