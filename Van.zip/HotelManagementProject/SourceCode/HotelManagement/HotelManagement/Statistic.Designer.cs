﻿namespace HotelManagement
{
    partial class Statistic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.quanlythongkegb = new System.Windows.Forms.GroupBox();
            this.sapxepcbx = new System.Windows.Forms.CheckBox();
            this.ngaythongkedt = new System.Windows.Forms.DateTimePicker();
            this.ChonThongKe_Option = new System.Windows.Forms.Button();
            this.tenloaiphongtb = new System.Windows.Forms.TextBox();
            this.tenkstb = new System.Windows.Forms.TextBox();
            this.tenloaiphonglb = new System.Windows.Forms.Label();
            this.ngaythongkelb = new System.Windows.Forms.Label();
            this.tenkslb = new System.Windows.Forms.Label();
            this.danhsachthongke = new System.Windows.Forms.DataGridView();
            this.STT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maKS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenKS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thanhPho = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soSao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maLoaiPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenLoaiPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.slTrong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.danhsachthongkegb = new System.Windows.Forms.GroupBox();
            this.QuayLaisv_Option = new System.Windows.Forms.Button();
            this.quanlythongkegb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.danhsachthongke)).BeginInit();
            this.danhsachthongkegb.SuspendLayout();
            this.SuspendLayout();
            // 
            // quanlythongkegb
            // 
            this.quanlythongkegb.Controls.Add(this.sapxepcbx);
            this.quanlythongkegb.Controls.Add(this.ngaythongkedt);
            this.quanlythongkegb.Controls.Add(this.ChonThongKe_Option);
            this.quanlythongkegb.Controls.Add(this.tenloaiphongtb);
            this.quanlythongkegb.Controls.Add(this.tenkstb);
            this.quanlythongkegb.Controls.Add(this.tenloaiphonglb);
            this.quanlythongkegb.Controls.Add(this.ngaythongkelb);
            this.quanlythongkegb.Controls.Add(this.tenkslb);
            this.quanlythongkegb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quanlythongkegb.Location = new System.Drawing.Point(44, 43);
            this.quanlythongkegb.Name = "quanlythongkegb";
            this.quanlythongkegb.Size = new System.Drawing.Size(727, 105);
            this.quanlythongkegb.TabIndex = 29;
            this.quanlythongkegb.TabStop = false;
            this.quanlythongkegb.Text = "QUẢN LÝ THỐNG KÊ";
            // 
            // sapxepcbx
            // 
            this.sapxepcbx.AutoSize = true;
            this.sapxepcbx.Location = new System.Drawing.Point(617, 59);
            this.sapxepcbx.Name = "sapxepcbx";
            this.sapxepcbx.Size = new System.Drawing.Size(85, 22);
            this.sapxepcbx.TabIndex = 32;
            this.sapxepcbx.Text = "Sắp xếp";
            this.sapxepcbx.UseVisualStyleBackColor = true;
            // 
            // ngaythongkedt
            // 
            this.ngaythongkedt.Location = new System.Drawing.Point(318, 59);
            this.ngaythongkedt.Name = "ngaythongkedt";
            this.ngaythongkedt.Size = new System.Drawing.Size(130, 26);
            this.ngaythongkedt.TabIndex = 30;
            // 
            // ChonThongKe_Option
            // 
            this.ChonThongKe_Option.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(26)))), ((int)(((byte)(52)))));
            this.ChonThongKe_Option.FlatAppearance.BorderSize = 0;
            this.ChonThongKe_Option.Font = new System.Drawing.Font("Arial", 12F);
            this.ChonThongKe_Option.ForeColor = System.Drawing.Color.White;
            this.ChonThongKe_Option.Location = new System.Drawing.Point(488, 56);
            this.ChonThongKe_Option.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.ChonThongKe_Option.Name = "ChonThongKe_Option";
            this.ChonThongKe_Option.Size = new System.Drawing.Size(100, 30);
            this.ChonThongKe_Option.TabIndex = 29;
            this.ChonThongKe_Option.Text = "Chọn";
            this.ChonThongKe_Option.UseVisualStyleBackColor = false;
            this.ChonThongKe_Option.Click += new System.EventHandler(this.ChonThongKe_Option_Click);
            // 
            // tenloaiphongtb
            // 
            this.tenloaiphongtb.Location = new System.Drawing.Point(168, 59);
            this.tenloaiphongtb.Name = "tenloaiphongtb";
            this.tenloaiphongtb.Size = new System.Drawing.Size(130, 26);
            this.tenloaiphongtb.TabIndex = 20;
            this.tenloaiphongtb.TextChanged += new System.EventHandler(this.tenloaiphongtb_TextChanged);
            // 
            // tenkstb
            // 
            this.tenkstb.Location = new System.Drawing.Point(18, 59);
            this.tenkstb.Name = "tenkstb";
            this.tenkstb.Size = new System.Drawing.Size(130, 26);
            this.tenkstb.TabIndex = 19;
            this.tenkstb.TextChanged += new System.EventHandler(this.tenkstb_TextChanged);
            // 
            // tenloaiphonglb
            // 
            this.tenloaiphonglb.AutoSize = true;
            this.tenloaiphonglb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tenloaiphonglb.Location = new System.Drawing.Point(165, 39);
            this.tenloaiphonglb.Name = "tenloaiphonglb";
            this.tenloaiphonglb.Size = new System.Drawing.Size(110, 18);
            this.tenloaiphonglb.TabIndex = 14;
            this.tenloaiphonglb.Text = "Tên loại phòng";
            // 
            // ngaythongkelb
            // 
            this.ngaythongkelb.AutoSize = true;
            this.ngaythongkelb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ngaythongkelb.Location = new System.Drawing.Point(315, 39);
            this.ngaythongkelb.Name = "ngaythongkelb";
            this.ngaythongkelb.Size = new System.Drawing.Size(107, 18);
            this.ngaythongkelb.TabIndex = 16;
            this.ngaythongkelb.Text = "Ngày thống kê";
            // 
            // tenkslb
            // 
            this.tenkslb.AutoSize = true;
            this.tenkslb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tenkslb.Location = new System.Drawing.Point(15, 39);
            this.tenkslb.Name = "tenkslb";
            this.tenkslb.Size = new System.Drawing.Size(108, 18);
            this.tenkslb.TabIndex = 18;
            this.tenkslb.Text = "Tên khách sạn";
            // 
            // danhsachthongke
            // 
            this.danhsachthongke.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.danhsachthongke.ColumnHeadersHeight = 30;
            this.danhsachthongke.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.STT,
            this.maKS,
            this.tenKS,
            this.thanhPho,
            this.soSao,
            this.maLoaiPhong,
            this.tenLoaiPhong,
            this.slTrong});
            this.danhsachthongke.Location = new System.Drawing.Point(11, 25);
            this.danhsachthongke.Name = "danhsachthongke";
            this.danhsachthongke.RowHeadersWidth = 90;
            this.danhsachthongke.Size = new System.Drawing.Size(1181, 459);
            this.danhsachthongke.TabIndex = 0;
            // 
            // STT
            // 
            this.STT.Frozen = true;
            this.STT.HeaderText = "STT";
            this.STT.Name = "STT";
            // 
            // maKS
            // 
            this.maKS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.maKS.Frozen = true;
            this.maKS.HeaderText = "Mã khách sạn";
            this.maKS.Name = "maKS";
            this.maKS.Width = 129;
            // 
            // tenKS
            // 
            this.tenKS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.tenKS.Frozen = true;
            this.tenKS.HeaderText = "Tên khách sạn";
            this.tenKS.Name = "tenKS";
            this.tenKS.Width = 133;
            // 
            // thanhPho
            // 
            this.thanhPho.Frozen = true;
            this.thanhPho.HeaderText = "Thành phố";
            this.thanhPho.Name = "thanhPho";
            // 
            // soSao
            // 
            this.soSao.Frozen = true;
            this.soSao.HeaderText = "Số sao";
            this.soSao.Name = "soSao";
            // 
            // maLoaiPhong
            // 
            this.maLoaiPhong.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.maLoaiPhong.Frozen = true;
            this.maLoaiPhong.HeaderText = "Mã loại phòng";
            this.maLoaiPhong.Name = "maLoaiPhong";
            this.maLoaiPhong.Width = 131;
            // 
            // tenLoaiPhong
            // 
            this.tenLoaiPhong.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.tenLoaiPhong.HeaderText = "Tên loại phòng";
            this.tenLoaiPhong.Name = "tenLoaiPhong";
            this.tenLoaiPhong.Width = 135;
            // 
            // slTrong
            // 
            this.slTrong.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.slTrong.HeaderText = "Số phòng trống";
            this.slTrong.Name = "slTrong";
            this.slTrong.Width = 139;
            // 
            // danhsachthongkegb
            // 
            this.danhsachthongkegb.Controls.Add(this.danhsachthongke);
            this.danhsachthongkegb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.danhsachthongkegb.Location = new System.Drawing.Point(44, 172);
            this.danhsachthongkegb.Name = "danhsachthongkegb";
            this.danhsachthongkegb.Size = new System.Drawing.Size(1203, 495);
            this.danhsachthongkegb.TabIndex = 30;
            this.danhsachthongkegb.TabStop = false;
            this.danhsachthongkegb.Text = "DANH SÁCH THỐNG KÊ";
            // 
            // QuayLaisv_Option
            // 
            this.QuayLaisv_Option.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(3)))), ((int)(((byte)(149)))));
            this.QuayLaisv_Option.FlatAppearance.BorderSize = 0;
            this.QuayLaisv_Option.Font = new System.Drawing.Font("Arial", 12F);
            this.QuayLaisv_Option.ForeColor = System.Drawing.Color.White;
            this.QuayLaisv_Option.Location = new System.Drawing.Point(1147, 118);
            this.QuayLaisv_Option.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.QuayLaisv_Option.Name = "QuayLaisv_Option";
            this.QuayLaisv_Option.Size = new System.Drawing.Size(100, 30);
            this.QuayLaisv_Option.TabIndex = 31;
            this.QuayLaisv_Option.Text = "Quay Lại";
            this.QuayLaisv_Option.UseVisualStyleBackColor = false;
            // 
            // Statistic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(124)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(1301, 700);
            this.Controls.Add(this.QuayLaisv_Option);
            this.Controls.Add(this.danhsachthongkegb);
            this.Controls.Add(this.quanlythongkegb);
            this.Name = "Statistic";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Statistic";
            this.quanlythongkegb.ResumeLayout(false);
            this.quanlythongkegb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.danhsachthongke)).EndInit();
            this.danhsachthongkegb.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox quanlythongkegb;
        private System.Windows.Forms.Button ChonThongKe_Option;
        private System.Windows.Forms.TextBox tenloaiphongtb;
        private System.Windows.Forms.TextBox tenkstb;
        private System.Windows.Forms.Label tenloaiphonglb;
        private System.Windows.Forms.Label ngaythongkelb;
        private System.Windows.Forms.Label tenkslb;
        private System.Windows.Forms.DataGridView danhsachthongke;
        private System.Windows.Forms.GroupBox danhsachthongkegb;
        private System.Windows.Forms.DateTimePicker ngaythongkedt;
        private System.Windows.Forms.CheckBox sapxepcbx;
        private System.Windows.Forms.DataGridViewTextBoxColumn STT;
        private System.Windows.Forms.DataGridViewTextBoxColumn maKS;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenKS;
        private System.Windows.Forms.DataGridViewTextBoxColumn thanhPho;
        private System.Windows.Forms.DataGridViewTextBoxColumn soSao;
        private System.Windows.Forms.DataGridViewTextBoxColumn maLoaiPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenLoaiPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn slTrong;
        private System.Windows.Forms.Button QuayLaisv_Option;
    }
}