﻿namespace HotelManagement
{
    partial class Signin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hoten = new System.Windows.Forms.Label();
            this.hotentb = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tendangnhap = new System.Windows.Forms.Label();
            this.matkhautb = new System.Windows.Forms.TextBox();
            this.matkhau = new System.Windows.Forms.Label();
            this.nhaplaimatkhautb = new System.Windows.Forms.TextBox();
            this.nhaplaimatkhau = new System.Windows.Forms.Label();
            this.cmndtb = new System.Windows.Forms.TextBox();
            this.cmnd = new System.Windows.Forms.Label();
            this.diachitb = new System.Windows.Forms.TextBox();
            this.diachi = new System.Windows.Forms.Label();
            this.sdttb = new System.Windows.Forms.TextBox();
            this.sdt = new System.Windows.Forms.Label();
            this.emailtb = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.motatb = new System.Windows.Forms.TextBox();
            this.mota = new System.Windows.Forms.Label();
            this.HoanTat_Option = new System.Windows.Forms.Button();
            this.dangkitaikhoangb = new System.Windows.Forms.GroupBox();
            this.dangkitaikhoangb.SuspendLayout();
            this.SuspendLayout();
            // 
            // hoten
            // 
            this.hoten.AutoSize = true;
            this.hoten.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hoten.ForeColor = System.Drawing.Color.Black;
            this.hoten.Location = new System.Drawing.Point(128, 66);
            this.hoten.Name = "hoten";
            this.hoten.Size = new System.Drawing.Size(53, 18);
            this.hoten.TabIndex = 1;
            this.hoten.Text = "Họ tên";
            // 
            // hotentb
            // 
            this.hotentb.Location = new System.Drawing.Point(183, 60);
            this.hotentb.Multiline = true;
            this.hotentb.Name = "hotentb";
            this.hotentb.Size = new System.Drawing.Size(400, 30);
            this.hotentb.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(183, 110);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(400, 30);
            this.textBox2.TabIndex = 4;
            // 
            // tendangnhap
            // 
            this.tendangnhap.AutoSize = true;
            this.tendangnhap.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tendangnhap.ForeColor = System.Drawing.Color.Black;
            this.tendangnhap.Location = new System.Drawing.Point(70, 116);
            this.tendangnhap.Name = "tendangnhap";
            this.tendangnhap.Size = new System.Drawing.Size(111, 18);
            this.tendangnhap.TabIndex = 3;
            this.tendangnhap.Text = "Tên đăng nhập";
            // 
            // matkhautb
            // 
            this.matkhautb.Location = new System.Drawing.Point(183, 163);
            this.matkhautb.Multiline = true;
            this.matkhautb.Name = "matkhautb";
            this.matkhautb.Size = new System.Drawing.Size(400, 30);
            this.matkhautb.TabIndex = 6;
            // 
            // matkhau
            // 
            this.matkhau.AutoSize = true;
            this.matkhau.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.matkhau.ForeColor = System.Drawing.Color.Black;
            this.matkhau.Location = new System.Drawing.Point(110, 168);
            this.matkhau.Name = "matkhau";
            this.matkhau.Size = new System.Drawing.Size(71, 18);
            this.matkhau.TabIndex = 5;
            this.matkhau.Text = "Mật khẩu";
            // 
            // nhaplaimatkhautb
            // 
            this.nhaplaimatkhautb.Location = new System.Drawing.Point(183, 213);
            this.nhaplaimatkhautb.Multiline = true;
            this.nhaplaimatkhautb.Name = "nhaplaimatkhautb";
            this.nhaplaimatkhautb.Size = new System.Drawing.Size(400, 30);
            this.nhaplaimatkhautb.TabIndex = 8;
            // 
            // nhaplaimatkhau
            // 
            this.nhaplaimatkhau.AutoSize = true;
            this.nhaplaimatkhau.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nhaplaimatkhau.ForeColor = System.Drawing.Color.Black;
            this.nhaplaimatkhau.Location = new System.Drawing.Point(49, 219);
            this.nhaplaimatkhau.Name = "nhaplaimatkhau";
            this.nhaplaimatkhau.Size = new System.Drawing.Size(132, 18);
            this.nhaplaimatkhau.TabIndex = 7;
            this.nhaplaimatkhau.Text = "Nhập lại mật khẩu";
            // 
            // cmndtb
            // 
            this.cmndtb.Location = new System.Drawing.Point(183, 263);
            this.cmndtb.Multiline = true;
            this.cmndtb.Name = "cmndtb";
            this.cmndtb.Size = new System.Drawing.Size(400, 30);
            this.cmndtb.TabIndex = 10;
            // 
            // cmnd
            // 
            this.cmnd.AutoSize = true;
            this.cmnd.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmnd.ForeColor = System.Drawing.Color.Black;
            this.cmnd.Location = new System.Drawing.Point(125, 269);
            this.cmnd.Name = "cmnd";
            this.cmnd.Size = new System.Drawing.Size(56, 18);
            this.cmnd.TabIndex = 9;
            this.cmnd.Text = "CMND";
            // 
            // diachitb
            // 
            this.diachitb.Location = new System.Drawing.Point(183, 313);
            this.diachitb.Multiline = true;
            this.diachitb.Name = "diachitb";
            this.diachitb.Size = new System.Drawing.Size(400, 30);
            this.diachitb.TabIndex = 12;
            // 
            // diachi
            // 
            this.diachi.AutoSize = true;
            this.diachi.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diachi.ForeColor = System.Drawing.Color.Black;
            this.diachi.Location = new System.Drawing.Point(124, 319);
            this.diachi.Name = "diachi";
            this.diachi.Size = new System.Drawing.Size(57, 18);
            this.diachi.TabIndex = 11;
            this.diachi.Text = "Địa chỉ";
            // 
            // sdttb
            // 
            this.sdttb.Location = new System.Drawing.Point(183, 363);
            this.sdttb.Multiline = true;
            this.sdttb.Name = "sdttb";
            this.sdttb.Size = new System.Drawing.Size(400, 30);
            this.sdttb.TabIndex = 14;
            // 
            // sdt
            // 
            this.sdt.AutoSize = true;
            this.sdt.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdt.ForeColor = System.Drawing.Color.Black;
            this.sdt.Location = new System.Drawing.Point(81, 369);
            this.sdt.Name = "sdt";
            this.sdt.Size = new System.Drawing.Size(100, 18);
            this.sdt.TabIndex = 13;
            this.sdt.Text = "Số điện thoại";
            // 
            // emailtb
            // 
            this.emailtb.Location = new System.Drawing.Point(183, 414);
            this.emailtb.Multiline = true;
            this.emailtb.Name = "emailtb";
            this.emailtb.Size = new System.Drawing.Size(400, 30);
            this.emailtb.TabIndex = 16;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Black;
            this.email.Location = new System.Drawing.Point(133, 420);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(48, 18);
            this.email.TabIndex = 15;
            this.email.Text = "Email";
            // 
            // motatb
            // 
            this.motatb.Location = new System.Drawing.Point(183, 465);
            this.motatb.Multiline = true;
            this.motatb.Name = "motatb";
            this.motatb.Size = new System.Drawing.Size(400, 90);
            this.motatb.TabIndex = 18;
            // 
            // mota
            // 
            this.mota.AutoSize = true;
            this.mota.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mota.ForeColor = System.Drawing.Color.Black;
            this.mota.Location = new System.Drawing.Point(134, 471);
            this.mota.Name = "mota";
            this.mota.Size = new System.Drawing.Size(47, 18);
            this.mota.TabIndex = 17;
            this.mota.Text = "Mô tả";
            // 
            // HoanTat_Option
            // 
            this.HoanTat_Option.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(26)))), ((int)(((byte)(52)))));
            this.HoanTat_Option.FlatAppearance.BorderSize = 0;
            this.HoanTat_Option.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.HoanTat_Option.ForeColor = System.Drawing.Color.White;
            this.HoanTat_Option.Location = new System.Drawing.Point(605, 495);
            this.HoanTat_Option.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.HoanTat_Option.Name = "HoanTat_Option";
            this.HoanTat_Option.Size = new System.Drawing.Size(150, 60);
            this.HoanTat_Option.TabIndex = 19;
            this.HoanTat_Option.Text = "Hoàn Tất";
            this.HoanTat_Option.UseVisualStyleBackColor = false;
            // 
            // dangkitaikhoangb
            // 
            this.dangkitaikhoangb.Controls.Add(this.hotentb);
            this.dangkitaikhoangb.Controls.Add(this.HoanTat_Option);
            this.dangkitaikhoangb.Controls.Add(this.hoten);
            this.dangkitaikhoangb.Controls.Add(this.motatb);
            this.dangkitaikhoangb.Controls.Add(this.textBox2);
            this.dangkitaikhoangb.Controls.Add(this.mota);
            this.dangkitaikhoangb.Controls.Add(this.tendangnhap);
            this.dangkitaikhoangb.Controls.Add(this.emailtb);
            this.dangkitaikhoangb.Controls.Add(this.matkhautb);
            this.dangkitaikhoangb.Controls.Add(this.email);
            this.dangkitaikhoangb.Controls.Add(this.matkhau);
            this.dangkitaikhoangb.Controls.Add(this.sdttb);
            this.dangkitaikhoangb.Controls.Add(this.nhaplaimatkhau);
            this.dangkitaikhoangb.Controls.Add(this.sdt);
            this.dangkitaikhoangb.Controls.Add(this.nhaplaimatkhautb);
            this.dangkitaikhoangb.Controls.Add(this.diachitb);
            this.dangkitaikhoangb.Controls.Add(this.cmnd);
            this.dangkitaikhoangb.Controls.Add(this.diachi);
            this.dangkitaikhoangb.Controls.Add(this.cmndtb);
            this.dangkitaikhoangb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dangkitaikhoangb.Location = new System.Drawing.Point(251, 67);
            this.dangkitaikhoangb.Name = "dangkitaikhoangb";
            this.dangkitaikhoangb.Size = new System.Drawing.Size(773, 589);
            this.dangkitaikhoangb.TabIndex = 20;
            this.dangkitaikhoangb.TabStop = false;
            this.dangkitaikhoangb.Text = "ĐĂNG KÍ TÀI KHOẢN";
            // 
            // Signin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(124)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(1301, 700);
            this.Controls.Add(this.dangkitaikhoangb);
            this.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.Name = "Signin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Signin";
            this.dangkitaikhoangb.ResumeLayout(false);
            this.dangkitaikhoangb.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label hoten;
        private System.Windows.Forms.TextBox hotentb;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label tendangnhap;
        private System.Windows.Forms.TextBox matkhautb;
        private System.Windows.Forms.Label matkhau;
        private System.Windows.Forms.TextBox nhaplaimatkhautb;
        private System.Windows.Forms.Label nhaplaimatkhau;
        private System.Windows.Forms.TextBox cmndtb;
        private System.Windows.Forms.Label cmnd;
        private System.Windows.Forms.TextBox diachitb;
        private System.Windows.Forms.Label diachi;
        private System.Windows.Forms.TextBox sdttb;
        private System.Windows.Forms.Label sdt;
        private System.Windows.Forms.TextBox emailtb;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.TextBox motatb;
        private System.Windows.Forms.Label mota;
        private System.Windows.Forms.Button HoanTat_Option;
        private System.Windows.Forms.GroupBox dangkitaikhoangb;
    }
}